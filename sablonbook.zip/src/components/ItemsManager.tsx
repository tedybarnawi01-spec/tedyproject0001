import React, { useState } from 'react';
import { useStore } from '../store';
import { formatRupiah } from '../lib/utils';
import { Plus, Trash2, Edit2, X } from 'lucide-react';

export function ItemsManager() {
  const { items, addItem, deleteItem, updateItem } = useStore();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', date: new Date().toISOString().split('T')[0], quantity: '1', costPrice: '', sellingPrice: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const itemData = {
      name: formData.name,
      date: formData.date,
      quantity: Number(formData.quantity),
      costPrice: Number(formData.costPrice),
      sellingPrice: Number(formData.sellingPrice),
    };

    if (editingId) {
      updateItem(editingId, itemData);
    } else {
      addItem(itemData);
    }
    
    setIsFormOpen(false);
    setEditingId(null);
    setFormData({ name: '', date: new Date().toISOString().split('T')[0], quantity: '1', costPrice: '', sellingPrice: '' });
  };

  const handleEdit = (item: any) => {
    setFormData({
      name: item.name,
      date: item.date || new Date().toISOString().split('T')[0],
      quantity: item.quantity?.toString() || '1',
      costPrice: item.costPrice.toString(),
      sellingPrice: item.sellingPrice.toString(),
    });
    setEditingId(item.id);
    setIsFormOpen(true);
  };

  const handleCancel = () => {
    setIsFormOpen(false);
    setEditingId(null);
    setFormData({ name: '', date: new Date().toISOString().split('T')[0], quantity: '1', costPrice: '', sellingPrice: '' });
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-white">Input Barang Produksi</h3>
        {!isFormOpen && (
          <button
            onClick={() => setIsFormOpen(true)}
            className="text-xs text-teal-500 hover:underline flex items-center gap-1"
          >
            <Plus size={14} /> Tambah Baru
          </button>
        )}
      </div>

      {isFormOpen && (
        <div className="p-5 bg-[#121212] border border-[#222] rounded-lg">
          <div className="flex justify-between items-center mb-4">
            <p className="text-xs text-[#666] uppercase font-semibold">{editingId ? 'Edit Data Produksi' : 'Catat Data Produksi'}</p>
            <button onClick={handleCancel} className="text-[#666] hover:text-white">
              <X size={16} />
            </button>
          </div>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="md:col-span-2">
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
                placeholder="Nama Barang (Contoh: Kaos Cotton 30s)"
              />
            </div>
            <div>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-[#888] focus:border-teal-500 outline-none rounded"
                style={{ colorScheme: 'dark' }}
              />
            </div>
            <div>
              <input
                type="number"
                required
                min="1"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
                placeholder="Jumlah Pcs"
              />
            </div>
            <div>
              <input
                type="number"
                required
                min="0"
                value={formData.sellingPrice}
                onChange={(e) => setFormData({ ...formData, sellingPrice: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
                placeholder="Harga per Pcs (Rp)"
              />
            </div>
            <div className="md:col-span-5 flex justify-end gap-3 mt-2">
              <button
                type="button"
                onClick={handleCancel}
                className="py-2 px-4 bg-[#1A1A1A] border border-[#333] hover:border-teal-500 text-[#CCC] text-xs font-medium rounded uppercase tracking-tighter"
              >
                Batal
              </button>
              <button
                type="submit"
                className="py-2 px-4 bg-teal-600 hover:bg-teal-500 text-black text-xs font-bold rounded uppercase tracking-tighter"
              >
                Simpan
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="flex-1 border border-[#222] rounded bg-[#0F0F0F] overflow-hidden flex flex-col">
        <div className="grid grid-cols-6 text-[10px] uppercase font-bold text-[#555] bg-[#161616] p-3 border-b border-[#222]">
          <span>Tanggal</span>
          <span className="col-span-2">Nama Barang</span>
          <span>Jumlah</span>
          <span>Harga per Pcs</span>
          <span className="text-right">Aksi</span>
        </div>
        <div className="flex-1 overflow-y-auto font-mono text-xs">
          {items.length === 0 ? (
            <div className="p-6 text-center text-[#666] text-xs uppercase tracking-widest font-bold">
              Belum ada data barang
            </div>
          ) : (
            [...items].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((item) => (
              <div key={item.id} className="grid grid-cols-6 p-3 border-b border-[#181818] hover:bg-[#151515] items-center">
                <span className="text-[#777]">{item.date ? new Date(item.date).toLocaleDateString('id-ID', {day: '2-digit', month: '2-digit', year: '2-digit'}) : '-'}</span>
                <span className="text-white col-span-2 font-sans">{item.name}</span>
                <span className="text-[#777]">{item.quantity || 1} Pcs</span>
                <span className="text-[#777]">{formatRupiah(item.sellingPrice)}</span>
                <span className="text-right flex justify-end gap-2">
                  <button
                    onClick={() => handleEdit(item)}
                    className="p-1 text-[#666] hover:text-teal-400 transition-colors"
                  >
                    <Edit2 size={14} />
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm('Yakin ingin menghapus barang ini?')) {
                        deleteItem(item.id);
                      }
                    }}
                    className="p-1 text-[#666] hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
