import React, { useState, useMemo } from 'react';
import { Plus, Trash2, Edit2, X, FileText, Check, Printer } from 'lucide-react';
import { useStore } from '../store';
import { formatRupiah } from '../lib/utils';
import { Payment } from '../types';

export function PaymentsManager() {
  const { payments, items, addPayment, deletePayment, updatePayment } = useStore();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ 
    date: new Date().toISOString().split('T')[0], 
    clientName: '', 
    description: '', 
    amount: '' 
  });
  
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [markAsPaid, setMarkAsPaid] = useState(false);
  const [printingPayment, setPrintingPayment] = useState<Payment | null>(null);
  
  const unpaidItems = useMemo(() => items.filter(i => !i.isPaid), [items]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Determine amount: if manual amount is given, use it. Otherwise, sum the selected items.
    let amountToSave = Number(formData.amount);
    
    if (selectedItemIds.length > 0 && amountToSave === 0) {
       amountToSave = selectedItemIds.reduce((sum, id) => {
           const item = items.find(i => i.id === id);
           return sum + (item ? (item.sellingPrice * (item.quantity || 1)) : 0);
       }, 0);
    }
    
    const paymentData = {
      date: formData.date,
      clientName: formData.clientName,
      description: formData.description,
      amount: amountToSave,
      productionItemIds: selectedItemIds,
    };
    
    if (editingId) {
      updatePayment(editingId, paymentData, markAsPaid);
    } else {
      addPayment(paymentData, markAsPaid);
    }
    
    setIsFormOpen(false);
    setEditingId(null);
    setFormData({ date: new Date().toISOString().split('T')[0], clientName: '', description: '', amount: '' });
    setSelectedItemIds([]);
    setMarkAsPaid(false);
  };

  const handleEdit = (payment: Payment) => {
    setEditingId(payment.id);
    setIsFormOpen(true);
    setFormData({
      date: payment.date,
      clientName: payment.clientName,
      description: payment.description,
      amount: payment.amount.toString(),
    });
    setSelectedItemIds(payment.productionItemIds || []);
  };

  const handleCancel = () => {
    setIsFormOpen(false);
    setEditingId(null);
    setFormData({ date: new Date().toISOString().split('T')[0], clientName: '', description: '', amount: '' });
    setSelectedItemIds([]);
    setMarkAsPaid(false);
  };

  const toggleItemSelection = (id: string) => {
    setSelectedItemIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };
  
  // Calculate running total for selected items
  const selectedTotal = useMemo(() => {
     return selectedItemIds.reduce((sum, id) => {
           const item = items.find(i => i.id === id);
           return sum + (item ? (item.sellingPrice * (item.quantity || 1)) : 0);
       }, 0);
  }, [selectedItemIds, items]);

  return (
    <>
    <div className={`h-full flex flex-col gap-6 ${printingPayment ? 'hidden print:hidden' : 'print:block'}`}>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-white">Pembayaran & Invoice</h3>
        {!isFormOpen && (
          <button
            onClick={() => setIsFormOpen(true)}
            className="flex items-center gap-2 bg-teal-500/10 text-teal-400 px-3 py-1.5 rounded text-xs font-medium hover:bg-teal-500/20 transition-colors"
          >
            <Plus size={16} /> Buat Pembayaran
          </button>
        )}
      </div>

      {isFormOpen && (
        <div className="p-5 bg-[#121212] border border-[#222] rounded-lg">
          <div className="flex justify-between items-center mb-4">
            <p className="text-xs text-[#666] uppercase font-semibold">{editingId ? 'Edit Pembayaran' : 'Terima Pembayaran & Invoice'}</p>
            <button onClick={handleCancel} className="text-[#666] hover:text-white">
              <X size={16} />
            </button>
          </div>
          
          <div className="mb-4">
             <p className="text-xs text-white mb-2 font-medium">Pilih Data Produksi Belum Lunas (Opsional):</p>
             <div className="max-h-32 overflow-y-auto border border-[#222] rounded bg-[#161616]">
                {unpaidItems.length === 0 && !editingId ? (
                   <div className="p-3 text-xs text-[#666]">Tidak ada tagihan yang belum lunas.</div>
                ) : (
                   <div className="flex flex-col">
                      {/* Show currently selected items first if editing */}
                      {editingId && items.filter(i => selectedItemIds.includes(i.id)).map(item => (
                         <label key={item.id} onClick={() => toggleItemSelection(item.id)} className="flex items-center gap-3 p-2 hover:bg-[#1A1A1A] cursor-pointer border-b border-[#222]">
                            <div className={`w-4 h-4 rounded border flex items-center justify-center ${selectedItemIds.includes(item.id) ? 'bg-teal-500 border-teal-500 text-black' : 'border-[#444]'}`}>
                                {selectedItemIds.includes(item.id) && <Check size={12} />}
                            </div>
                            <span className="text-xs text-white flex-1">{item.name} ({item.quantity} Pcs)</span>
                            <span className="text-xs text-teal-400">{formatRupiah(item.sellingPrice * (item.quantity || 1))}</span>
                         </label>
                      ))}
                      {/* Show unpaid items */}
                      {unpaidItems.map(item => (
                         <label key={item.id} onClick={() => toggleItemSelection(item.id)} className="flex items-center gap-3 p-2 hover:bg-[#1A1A1A] cursor-pointer border-b border-[#222]">
                            <div className={`w-4 h-4 rounded border flex items-center justify-center ${selectedItemIds.includes(item.id) ? 'bg-teal-500 border-teal-500 text-black' : 'border-[#444]'}`}>
                                {selectedItemIds.includes(item.id) && <Check size={12} />}
                            </div>
                            <span className="text-xs text-[#CCC] flex-1">{item.name} ({item.quantity} Pcs)</span>
                            <span className="text-xs text-teal-400">{formatRupiah(item.sellingPrice * (item.quantity || 1))}</span>
                         </label>
                      ))}
                   </div>
                )}
             </div>
          </div>
          
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-[10px] text-[#666] uppercase mb-1 block">Tanggal</label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-[#888] focus:border-teal-500 outline-none rounded"
                style={{ colorScheme: 'dark' }}
              />
            </div>
            <div>
              <label className="text-[10px] text-[#666] uppercase mb-1 block">Nama Client</label>
              <input
                type="text"
                required
                value={formData.clientName}
                onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
                placeholder="Client / Perusahaan"
              />
            </div>
            <div>
              <label className="text-[10px] text-[#666] uppercase mb-1 block">Keterangan</label>
              <input
                type="text"
                required
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
                placeholder="Deskripsi"
              />
            </div>
            <div className="md:col-span-2">
              <label className="text-[10px] text-[#666] uppercase mb-1 block">Nominal (Rp)</label>
              <input
                type="number"
                required
                min="0"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
                placeholder="0"
              />
              {selectedTotal > 0 && (
                 <p className="text-[10px] text-teal-500 mt-1">Total item terpilih: {formatRupiah(selectedTotal)}</p>
              )}
            </div>
            <div className="md:col-span-2 flex items-end mb-2">
               <label className="flex items-center gap-2 cursor-pointer text-sm text-[#CCC] hover:text-white transition-colors">
                  <div className={`w-4 h-4 rounded border flex items-center justify-center ${markAsPaid ? 'bg-teal-500 border-teal-500 text-black' : 'border-[#444]'}`}>
                      {markAsPaid && <Check size={12} />}
                  </div>
                  <input type="checkbox" className="hidden" checked={markAsPaid} onChange={(e) => setMarkAsPaid(e.target.checked)} />
                  Tandai item terpilih sebagai lunas
               </label>
            </div>
            <div className="lg:col-span-4 flex justify-end gap-3 mt-2">
              <button
                type="button"
                onClick={handleCancel}
                className="px-4 py-2 text-xs font-medium text-[#888] hover:text-white transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium bg-teal-500 text-black rounded hover:bg-teal-400 transition-colors"
              >
                Simpan Pembayaran
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="flex-1 border border-[#222] rounded bg-[#0F0F0F] overflow-hidden flex flex-col">
        <div className="grid grid-cols-6 text-[10px] uppercase font-bold text-[#555] bg-[#161616] p-3 border-b border-[#222]">
          <span>Tanggal</span>
          <span>Nama Client</span>
          <span className="col-span-2">Deskripsi Order</span>
          <span>Nominal Pembayaran</span>
          <span className="text-right">Aksi</span>
        </div>
        <div className="flex-1 overflow-y-auto font-mono text-xs">
          {payments.length === 0 ? (
            <div className="p-6 text-center text-[#666] text-xs uppercase tracking-widest font-bold">
              Belum ada riwayat pembayaran
            </div>
          ) : (
            [...payments].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((payment) => (
              <div key={payment.id} className="grid grid-cols-6 p-3 border-b border-[#181818] hover:bg-[#151515] items-center">
                <span className="text-[#777]">{payment.date ? new Date(payment.date).toLocaleDateString('id-ID', {day: '2-digit', month: '2-digit', year: '2-digit'}) : '-'}</span>
                <span className="text-white font-sans">{payment.clientName}</span>
                <span className="text-[#999] truncate pr-4 col-span-2">
                  {payment.description}
                  {payment.productionItemIds && payment.productionItemIds.length > 0 && (
                     <span className="ml-2 text-[10px] bg-teal-500/10 text-teal-400 px-1.5 py-0.5 rounded border border-teal-500/20">
                         {payment.productionItemIds.length} item
                     </span>
                  )}
                </span>
                <span className="text-teal-400 font-bold">+{formatRupiah(payment.amount)}</span>
                <span className="text-right flex justify-end gap-2">
                  <button
                    onClick={() => {
                      setPrintingPayment(payment);
                      setTimeout(() => window.print(), 100);
                    }}
                    className="p-1.5 text-[#555] hover:text-teal-400 transition-colors"
                    title="Cetak Invoice"
                  >
                    <Printer size={14} />
                  </button>
                  <button
                    onClick={() => handleEdit(payment)}
                    className="p-1.5 text-[#555] hover:text-teal-400 transition-colors"
                  >
                    <Edit2 size={14} />
                  </button>
                  <button
                    onClick={() => deletePayment(payment.id)}
                    className="p-1.5 text-[#555] hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>

    {printingPayment && (
      <div className="fixed inset-0 bg-white z-50 text-black p-4 md:p-8 overflow-auto print:static print:p-0 print:m-0 print:block">
         <div className="print:hidden mb-8 flex justify-between items-center max-w-3xl mx-auto">
            <h2 className="text-xl font-bold">Preview Invoice</h2>
            <div className="flex gap-4">
               <button onClick={() => setPrintingPayment(null)} className="px-4 py-2 border rounded hover:bg-gray-100">Tutup</button>
               <button onClick={() => window.print()} className="px-4 py-2 bg-teal-600 text-white rounded hover:bg-teal-700 flex items-center gap-2">
                 <Printer size={16} /> Cetak
               </button>
            </div>
         </div>
         <div className="max-w-3xl mx-auto border p-8 rounded bg-white shadow-sm print:border-none print:shadow-none print:p-0">
            <div className="text-center mb-8 border-b-2 border-black pb-4">
              <h1 className="text-3xl font-bold mb-1">INVOICE PEMBAYARAN</h1>
              <p className="text-gray-600 text-sm">Tanggal: {new Date(printingPayment.date).toLocaleDateString('id-ID')}</p>
            </div>

            <div className="mb-8">
              <p className="font-bold text-gray-500 text-sm mb-1">Kepada Yth:</p>
              <p className="text-lg font-bold">{printingPayment.clientName}</p>
              <p className="text-gray-700">{printingPayment.description}</p>
            </div>

            <table className="w-full mb-8 border-collapse">
              <thead>
                <tr className="border-b-2 border-black bg-gray-50">
                  <th className="text-left py-3 px-2">Item Produksi</th>
                  <th className="text-center py-3 px-2">Qty</th>
                  <th className="text-right py-3 px-2">Harga Satuan</th>
                  <th className="text-right py-3 px-2">Total</th>
                </tr>
              </thead>
              <tbody>
                {items.filter(i => printingPayment.productionItemIds?.includes(i.id)).map(item => (
                  <tr key={item.id} className="border-b border-gray-200">
                    <td className="py-3 px-2">{item.name}</td>
                    <td className="text-center py-3 px-2">{item.quantity} Pcs</td>
                    <td className="text-right py-3 px-2">{formatRupiah(item.sellingPrice)}</td>
                    <td className="text-right py-3 px-2">{formatRupiah(item.sellingPrice * (item.quantity || 1))}</td>
                  </tr>
                ))}
                {(!printingPayment.productionItemIds || printingPayment.productionItemIds.length === 0) && (
                  <tr>
                    <td colSpan={4} className="text-center py-6 text-gray-400 italic">Tidak ada detail item yang dipilih</td>
                  </tr>
                )}
              </tbody>
              <tfoot className="bg-gray-50/50">
                <tr>
                  <td colSpan={3} className="text-right py-3 px-2 font-bold text-gray-600">Total Tagihan Item:</td>
                  <td className="text-right py-3 px-2 font-bold">
                    {formatRupiah(items.filter(i => printingPayment.productionItemIds?.includes(i.id)).reduce((sum, item) => sum + (item.sellingPrice * (item.quantity || 1)), 0))}
                  </td>
                </tr>
                <tr className="border-b-2 border-black border-dashed">
                  <td colSpan={3} className="text-right py-3 px-2 font-bold text-teal-600">Jumlah Pembayaran:</td>
                  <td className="text-right py-3 px-2 font-bold text-teal-600">
                    {formatRupiah(printingPayment.amount)}
                  </td>
                </tr>
                <tr>
                  <td colSpan={3} className="text-right py-3 px-2 font-bold text-red-600">Sisa Tagihan Item Terpilih:</td>
                  <td className="text-right py-3 px-2 font-bold text-red-600">
                    {formatRupiah(Math.max(0, items.filter(i => printingPayment.productionItemIds?.includes(i.id)).reduce((sum, item) => sum + (item.sellingPrice * (item.quantity || 1)), 0) - printingPayment.amount))}
                  </td>
                </tr>
              </tfoot>
            </table>

            <div className="mt-16 flex justify-end">
              <div className="text-center">
                <p className="mb-20 text-gray-500 text-sm">Hormat Kami,</p>
                <p className="font-bold border-b border-black w-48 mx-auto"></p>
                <p className="mt-1 text-sm">Management</p>
              </div>
            </div>
         </div>
      </div>
    )}
    </>
  );
}
