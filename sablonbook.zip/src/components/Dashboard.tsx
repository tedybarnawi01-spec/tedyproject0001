import React, { useMemo } from 'react';
import { useStore } from '../store';
import { formatRupiah } from '../lib/utils';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, ArrowDownRight, Wallet, Receipt, CreditCard } from 'lucide-react';

export function Dashboard() {
  const { items, expenses, payments } = useStore();

  const metrics = useMemo(() => {
    const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);
    const totalPayments = payments.reduce((acc, curr) => acc + curr.amount, 0);

    const baseMetrics = items.reduce(
      (acc, curr) => {
        acc.omset += curr.sellingPrice * (curr.quantity || 1);
        acc.modal += curr.costPrice * (curr.quantity || 1);
        acc.laba += (curr.sellingPrice - curr.costPrice) * (curr.quantity || 1);
        return acc;
      },
      { omset: 0, modal: 0, laba: 0, pengeluaran: totalExpenses, piutang: 0 }
    );
    
    baseMetrics.piutang = Math.max(0, baseMetrics.omset - totalPayments);
    return baseMetrics;
  }, [items, expenses, payments]);

  const chartData = useMemo(() => {
    const grouped = items.reduce((acc, curr) => {
      const date = curr.date || new Date().toISOString().split('T')[0];
      if (!acc[date]) {
        acc[date] = { date: date, omset: 0, modal: 0, laba: 0 };
      }
      acc[date].omset += (curr.sellingPrice * (curr.quantity || 1));
      acc[date].modal += (curr.costPrice * (curr.quantity || 1));
      acc[date].laba += ((curr.sellingPrice - curr.costPrice) * (curr.quantity || 1));
      return acc;
    }, {} as Record<string, { date: string; omset: number; modal: number; laba: number }>);

    return Object.values(grouped).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [items]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-white">Ringkasan Performa</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="p-5 bg-[#121212] border border-[#222] rounded-lg">
          <div className="flex justify-between items-start mb-1">
            <div>
              <p className="text-xs text-[#666] uppercase font-semibold">Omset Kotor</p>
              <p className="text-xl font-light text-white mt-1">{formatRupiah(metrics.omset)}</p>
            </div>
            <TrendingUp className="w-5 h-5 text-[#666]" />
          </div>
        </div>

        <div className="p-5 bg-[#121212] border border-[#222] rounded-lg">
          <div className="flex justify-between items-start mb-1">
            <div>
              <p className="text-xs text-[#666] uppercase font-semibold">Beban Modal & Gaji</p>
              <p className="text-xl font-light text-white mt-1">{formatRupiah(metrics.modal + metrics.pengeluaran)}</p>
            </div>
            <ArrowDownRight className="w-5 h-5 text-[#666]" />
          </div>
        </div>

        <div className="p-5 bg-[#121212] border-2 border-amber-900/50 rounded-lg">
          <div className="flex justify-between items-start mb-1">
            <div>
              <p className="text-xs text-amber-500 uppercase font-bold">Piutang (Belum Lunas)</p>
              <p className="text-xl font-bold text-amber-400 mt-1">{formatRupiah(metrics.piutang)}</p>
            </div>
            <Receipt className="w-5 h-5 text-amber-500" />
          </div>
        </div>

        <div className="p-5 bg-[#121212] border-2 border-teal-900 rounded-lg">
          <div className="flex justify-between items-start mb-1">
            <div>
              <p className="text-xs text-teal-500 uppercase font-bold">Laba Bersih</p>
              <p className="text-xl font-bold text-teal-400 mt-1">{formatRupiah(metrics.laba - metrics.pengeluaran)}</p>
            </div>
            <Wallet className="w-5 h-5 text-teal-500" />
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex items-center justify-between mb-4 mt-2">
          <h3 className="text-sm font-medium text-white">Grafik Pendapatan</h3>
        </div>
        <div className="flex-1 border border-[#222] rounded bg-[#0F0F0F] p-4 overflow-hidden flex flex-col">
          {chartData.length > 0 ? (
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorLaba" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorOmset" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#818cf8" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#818cf8" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#222" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 10, fill: '#666', fontFamily: 'monospace' }}
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 10, fill: '#666', fontFamily: 'monospace' }}
                    tickFormatter={(value) => `Rp ${value / 1000}k`}
                  />
                  <Tooltip 
                    formatter={(value: number) => formatRupiah(value)}
                    contentStyle={{ backgroundColor: '#161616', borderRadius: '4px', border: '1px solid #333', color: '#E5E5E5', fontSize: '12px', fontFamily: 'monospace' }}
                    itemStyle={{ color: '#E5E5E5' }}
                  />
                  <Area type="monotone" dataKey="omset" name="Omset" stroke="#818cf8" strokeWidth={2} fillOpacity={1} fill="url(#colorOmset)" />
                  <Area type="monotone" dataKey="laba" name="Laba" stroke="#2dd4bf" strokeWidth={2} fillOpacity={1} fill="url(#colorLaba)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-[#666] text-xs uppercase tracking-widest font-bold">
              Belum ada data transaksi
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
