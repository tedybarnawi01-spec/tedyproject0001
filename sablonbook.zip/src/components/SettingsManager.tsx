import React, { useState } from 'react';
import { useStore } from '../store';
import { Save } from 'lucide-react';

export function SettingsManager() {
  const { settings, updateSettings } = useStore();
  
  const [formData, setFormData] = useState({
    appName: settings?.appName || 'SABLON PRO',
    appLogo: settings?.appLogo || 'S',
    adminPassword: settings?.adminPassword || 'admin123',
  });
  
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(formData);
    
    // Update current session auth if password changed
    localStorage.setItem('sablon_auth', 'true');
    
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="h-full flex flex-col gap-6 max-w-2xl">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-white">Pengaturan Sistem</h3>
      </div>

      <div className="bg-[#121212] border border-[#222] rounded-lg p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          
          <div className="space-y-4">
            <h4 className="text-xs text-teal-400 font-bold uppercase tracking-wider mb-2">Tampilan Aplikasi</h4>
            
            <div>
              <label className="text-[10px] text-[#666] uppercase mb-1 block">Nama Aplikasi</label>
              <input
                type="text"
                required
                value={formData.appName}
                onChange={(e) => setFormData({ ...formData, appName: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
              />
            </div>
            
            <div>
              <label className="text-[10px] text-[#666] uppercase mb-1 block">Logo (Teks Singkat)</label>
              <input
                type="text"
                required
                maxLength={3}
                value={formData.appLogo}
                onChange={(e) => setFormData({ ...formData, appLogo: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
                placeholder="Misal: S"
              />
              <p className="text-[#666] text-xs mt-1">Gunakan 1-3 karakter untuk ikon logo di menu.</p>
            </div>
          </div>
          
          <div className="border-t border-[#222] pt-6 space-y-4">
            <h4 className="text-xs text-teal-400 font-bold uppercase tracking-wider mb-2">Keamanan</h4>
            
            <div>
              <label className="text-[10px] text-[#666] uppercase mb-1 block">Password Admin</label>
              <input
                type="password"
                required
                value={formData.adminPassword}
                onChange={(e) => setFormData({ ...formData, adminPassword: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
              />
            </div>
          </div>

          <div className="border-t border-[#222] pt-4 flex items-center justify-between">
            {showSuccess ? (
              <span className="text-teal-500 text-sm font-medium">Pengaturan berhasil disimpan!</span>
            ) : (
              <span className="text-[#666] text-sm"></span>
            )}
            
            <button
              type="submit"
              className="flex items-center gap-2 bg-teal-600 text-white px-4 py-2 rounded text-sm font-medium hover:bg-teal-500 transition-colors"
            >
              <Save size={16} /> Simpan Pengaturan
            </button>
          </div>
          
        </form>
      </div>
    </div>
  );
}
