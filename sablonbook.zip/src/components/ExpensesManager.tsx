import React, { useState } from 'react';
import { Plus, Trash2, Edit2, X } from 'lucide-react';
import { useStore } from '../store';
import { formatRupiah } from '../lib/utils';
import { Expense } from '../types';

export function ExpensesManager() {
  const { expenses, addExpense, deleteExpense, updateExpense } = useStore();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ 
    date: new Date().toISOString().split('T')[0], 
    category: 'Bahan/Cat', 
    description: '', 
    amount: '' 
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const expenseData = {
      date: formData.date,
      category: formData.category as Expense['category'],
      description: formData.description,
      amount: Number(formData.amount),
    };
    
    if (editingId) {
      updateExpense(editingId, expenseData);
    } else {
      addExpense(expenseData);
    }
    
    setIsFormOpen(false);
    setEditingId(null);
    setFormData({ date: new Date().toISOString().split('T')[0], category: 'Bahan/Cat', description: '', amount: '' });
  };

  const handleEdit = (expense: Expense) => {
    setEditingId(expense.id);
    setIsFormOpen(true);
    setFormData({
      date: expense.date,
      category: expense.category,
      description: expense.description,
      amount: expense.amount.toString(),
    });
  };

  const handleCancel = () => {
    setIsFormOpen(false);
    setEditingId(null);
    setFormData({ date: new Date().toISOString().split('T')[0], category: 'Bahan/Cat', description: '', amount: '' });
  };

  return (
    <div className="h-full flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-white">Input Modal & Operasional</h3>
        {!isFormOpen && (
          <button
            onClick={() => setIsFormOpen(true)}
            className="flex items-center gap-2 bg-teal-500/10 text-teal-400 px-3 py-1.5 rounded text-xs font-medium hover:bg-teal-500/20 transition-colors"
          >
            <Plus size={16} /> Tambah Data
          </button>
        )}
      </div>

      {isFormOpen && (
        <div className="p-5 bg-[#121212] border border-[#222] rounded-lg">
          <div className="flex justify-between items-center mb-4">
            <p className="text-xs text-[#666] uppercase font-semibold">{editingId ? 'Edit Data Pengeluaran' : 'Catat Data Pengeluaran'}</p>
            <button onClick={handleCancel} className="text-[#666] hover:text-white">
              <X size={16} />
            </button>
          </div>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-[#888] focus:border-teal-500 outline-none rounded"
                style={{ colorScheme: 'dark' }}
              />
            </div>
            <div>
              <select
                required
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
              >
                <option value="Bahan/Cat">Bahan/Cat</option>
                <option value="Gaji Karyawan">Gaji Karyawan</option>
                <option value="Operasional">Operasional</option>
                <option value="Lainnya">Lainnya</option>
              </select>
            </div>
            <div className="md:col-span-2">
              <input
                type="text"
                required
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
                placeholder="Keterangan (contoh: Beli tinta plastisol)"
              />
            </div>
            <div className="md:col-span-4">
              <input
                type="number"
                required
                min="0"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="w-full bg-[#161616] border border-[#222] px-3 py-2 text-sm text-white focus:border-teal-500 outline-none rounded"
                placeholder="Nominal / Jumlah (Rp)"
              />
            </div>
            <div className="md:col-span-4 flex justify-end gap-3 mt-2">
              <button
                type="button"
                onClick={handleCancel}
                className="px-4 py-2 text-xs font-medium text-[#888] hover:text-white transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium bg-teal-500 text-black rounded hover:bg-teal-400 transition-colors"
              >
                Simpan
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="flex-1 border border-[#222] rounded bg-[#0F0F0F] overflow-hidden flex flex-col">
        <div className="grid grid-cols-6 text-[10px] uppercase font-bold text-[#555] bg-[#161616] p-3 border-b border-[#222]">
          <span>Tanggal</span>
          <span>Kategori</span>
          <span className="col-span-2">Keterangan</span>
          <span>Nominal</span>
          <span className="text-right">Aksi</span>
        </div>
        <div className="flex-1 overflow-y-auto font-mono text-xs">
          {expenses.length === 0 ? (
            <div className="p-6 text-center text-[#666] text-xs uppercase tracking-widest font-bold">
              Belum ada data pengeluaran
            </div>
          ) : (
            [...expenses].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((expense) => (
              <div key={expense.id} className="grid grid-cols-6 p-3 border-b border-[#181818] hover:bg-[#151515] items-center">
                <span className="text-[#777]">{expense.date ? new Date(expense.date).toLocaleDateString('id-ID', {day: '2-digit', month: '2-digit', year: '2-digit'}) : '-'}</span>
                <span className="text-white">
                  <span className={`px-2 py-0.5 rounded text-[10px] border ${
                    expense.category === 'Bahan/Cat' ? 'border-blue-500/20 text-blue-400 bg-blue-500/10' :
                    expense.category === 'Gaji Karyawan' ? 'border-purple-500/20 text-purple-400 bg-purple-500/10' :
                    expense.category === 'Operasional' ? 'border-orange-500/20 text-orange-400 bg-orange-500/10' :
                    'border-gray-500/20 text-gray-400 bg-gray-500/10'
                  }`}>
                    {expense.category}
                  </span>
                </span>
                <span className="text-[#999] col-span-2 truncate pr-4">{expense.description}</span>
                <span className="text-red-400">-{formatRupiah(expense.amount)}</span>
                <span className="text-right flex justify-end gap-2">
                  <button
                    onClick={() => handleEdit(expense)}
                    className="p-1.5 text-[#555] hover:text-teal-400 transition-colors"
                  >
                    <Edit2 size={14} />
                  </button>
                  <button
                    onClick={() => deleteExpense(expense.id)}
                    className="p-1.5 text-[#555] hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
