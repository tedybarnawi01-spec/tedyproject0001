import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Package, LogOut, Wallet, FileText, Settings } from 'lucide-react';
import { useStore } from '../store';

export function Layout() {
  const navigate = useNavigate();
  const { settings } = useStore();

  const handleLogout = () => {
    localStorage.removeItem('sablon_auth');
    navigate('/login');
  };

  const displayName = settings?.appName || 'SABLON PRO';
  const displayLogo = settings?.appLogo || 'S';

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#E5E5E5] flex pb-16 md:pb-0 font-sans print:bg-white print:text-black print:block print:pb-0">
      <aside className="w-64 bg-[#0E0E0E] border-r border-[#222] flex-col hidden md:flex print:hidden">
        <div className="h-16 flex items-center px-6 border-b border-[#222] gap-3">
          <div className="w-8 h-8 bg-teal-500 rounded flex items-center justify-center font-bold text-black">{displayLogo}</div>
          <h1 className="text-xl font-medium tracking-tight text-[#E5E5E5] truncate">{displayName}</h1>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 text-sm rounded transition-colors ${
                isActive ? 'bg-[#1A1A1A] text-teal-400 border border-[#333]' : 'text-[#888] hover:bg-[#161616] hover:text-[#CCC]'
              }`
            }
          >
            <LayoutDashboard size={20} />
            Dashboard
          </NavLink>
          <NavLink
            to="/items"
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 text-sm rounded transition-colors ${
                isActive ? 'bg-[#1A1A1A] text-teal-400 border border-[#333]' : 'text-[#888] hover:bg-[#161616] hover:text-[#CCC]'
              }`
            }
          >
            <Package size={20} />
            Data Produksi
          </NavLink>
          <NavLink
            to="/expenses"
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 text-sm rounded transition-colors ${
                isActive ? 'bg-[#1A1A1A] text-teal-400 border border-[#333]' : 'text-[#888] hover:bg-[#161616] hover:text-[#CCC]'
              }`
            }
          >
            <Wallet size={20} />
            Modal & Gaji
          </NavLink>
          <NavLink
            to="/payments"
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 text-sm rounded transition-colors ${
                isActive ? 'bg-[#1A1A1A] text-teal-400 border border-[#333]' : 'text-[#888] hover:bg-[#161616] hover:text-[#CCC]'
              }`
            }
          >
            <FileText size={20} />
            Pembayaran
          </NavLink>
          <NavLink
            to="/settings"
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 text-sm rounded transition-colors ${
                isActive ? 'bg-[#1A1A1A] text-teal-400 border border-[#333]' : 'text-[#888] hover:bg-[#161616] hover:text-[#CCC]'
              }`
            }
          >
            <Settings size={20} />
            Pengaturan
          </NavLink>
        </nav>
        <div className="p-4 border-t border-[#222]">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2 w-full text-left text-sm text-[#888] hover:bg-[#161616] hover:text-[#CCC] rounded transition-colors"
          >
            <LogOut size={20} />
            Keluar
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 bg-[#0A0A0A] print:bg-white print:block">
        <header className="h-16 bg-[#111] border-b border-[#222] flex items-center justify-between px-4 md:hidden print:hidden">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-teal-500 rounded flex items-center justify-center font-bold text-black text-xs">{displayLogo}</div>
              <h1 className="text-lg font-medium tracking-tight text-[#E5E5E5] truncate max-w-[150px]">{displayName}</h1>
            </div>
            <button onClick={handleLogout} className="p-2 text-[#888] hover:text-[#CCC]">
                <LogOut size={20} />
            </button>
        </header>
        <div className="flex-1 overflow-auto p-4 md:p-8 print:overflow-visible print:p-0">
          <Outlet />
        </div>
      </main>

      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#111] border-t border-[#222] flex justify-around p-2 z-50 print:hidden">
          <NavLink to="/" className={({ isActive }) => `flex flex-col items-center p-2 ${isActive ? 'text-teal-400' : 'text-[#666]'}`}>
            <LayoutDashboard size={24} />
            <span className="text-[10px] mt-1">Dashboard</span>
          </NavLink>
          <NavLink to="/items" className={({ isActive }) => `flex flex-col items-center p-2 ${isActive ? 'text-teal-400' : 'text-[#666]'}`}>
            <Package size={24} />
            <span className="text-[10px] mt-1">Produksi</span>
          </NavLink>
          <NavLink to="/expenses" className={({ isActive }) => `flex flex-col items-center p-2 ${isActive ? 'text-teal-400' : 'text-[#666]'}`}>
            <Wallet size={24} />
            <span className="text-[10px] mt-1">Modal</span>
          </NavLink>
          <NavLink to="/payments" className={({ isActive }) => `flex flex-col items-center p-2 ${isActive ? 'text-teal-400' : 'text-[#666]'}`}>
            <FileText size={24} />
            <span className="text-[10px] mt-1">Bayar</span>
          </NavLink>
          <NavLink to="/settings" className={({ isActive }) => `flex flex-col items-center p-2 ${isActive ? 'text-teal-400' : 'text-[#666]'}`}>
            <Settings size={24} />
            <span className="text-[10px] mt-1">Setelan</span>
          </NavLink>
      </div>
    </div>
  );
}
