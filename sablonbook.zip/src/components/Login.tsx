import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock } from 'lucide-react';
import { useStore } from '../store';

export function Login() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { settings } = useStore();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === (settings?.adminPassword || 'admin123')) {
      localStorage.setItem('sablon_auth', 'true');
      navigate('/');
    } else {
      setError('Password salah.');
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-4 font-sans text-[#E5E5E5]">
      <div className="w-full max-w-md bg-[#121212] border border-[#222] rounded-lg shadow-xl p-8">
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 bg-teal-500 rounded flex items-center justify-center mb-4 text-black text-xl font-bold">
            {settings?.appLogo || 'S'}
          </div>
          <h1 className="text-2xl font-medium tracking-tight text-[#E5E5E5]">
            {settings?.appName || 'SABLON PRO'}
          </h1>
          <p className="text-[10px] text-[#666] tracking-widest uppercase mt-2 text-center font-bold">Sistem Operasi Produksi Aktif</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#161616] border border-[#222] px-4 py-3 text-sm text-white focus:border-teal-500 outline-none rounded"
              placeholder="Masukkan password admin"
              required
            />
            {error && <p className="text-red-500 text-xs mt-2 font-mono">{error}</p>}
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-teal-600 hover:bg-teal-500 text-black text-sm font-bold rounded uppercase tracking-tighter transition-colors"
          >
            Akses Sistem
          </button>
        </form>
      </div>
    </div>
  );
}
