export interface Item {
  id: string;
  name: string;
  date: string;
  quantity: number;
  costPrice: number;
  sellingPrice: number;
  isPaid?: boolean;
}

export interface Expense {
  id: string;
  date: string;
  category: 'Bahan/Cat' | 'Gaji Karyawan' | 'Operasional' | 'Lainnya';
  description: string;
  amount: number;
}

export interface Settings {
  appName: string;
  appLogo: string;
  adminPassword?: string;
}

export interface Payment {
  id: string;
  date: string;
  clientName: string;
  description: string;
  amount: number;
  productionItemIds: string[];
}
