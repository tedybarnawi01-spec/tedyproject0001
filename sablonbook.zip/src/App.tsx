/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { StoreProvider } from './store';
import { Layout } from './components/Layout';
import { Login } from './components/Login';
import { Dashboard } from './components/Dashboard';
import { ItemsManager } from './components/ItemsManager';
import { ExpensesManager } from './components/ExpensesManager';
import { PaymentsManager } from './components/PaymentsManager';
import { SettingsManager } from './components/SettingsManager';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const isAuthenticated = localStorage.getItem('sablon_auth') === 'true';
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <StoreProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="items" element={<ItemsManager />} />
            <Route path="expenses" element={<ExpensesManager />} />
            <Route path="payments" element={<PaymentsManager />} />
            <Route path="settings" element={<SettingsManager />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </StoreProvider>
  );
}
