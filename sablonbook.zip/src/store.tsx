import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Item, Expense, Payment, Settings } from './types';
import { supabase } from './lib/supabase';

const defaultSettings: Settings = {
  appName: 'SABLON PRO',
  appLogo: 'S',
  adminPassword: 'admin123',
};

interface StoreContextType {
  items: Item[];
  expenses: Expense[];
  payments: Payment[];
  settings: Settings;
  addItem: (item: Omit<Item, 'id'>) => void;
  updateItem: (id: string, item: Omit<Item, 'id'>) => void;
  deleteItem: (id: string) => void;
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  updateExpense: (id: string, expense: Omit<Expense, 'id'>) => void;
  deleteExpense: (id: string) => void;
  addPayment: (payment: Omit<Payment, 'id'>, markAsPaid?: boolean) => void;
  updatePayment: (id: string, payment: Omit<Payment, 'id'>, markAsPaid?: boolean) => void;
  deletePayment: (id: string) => void;
  updateSettings: (settings: Settings) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Item[]>(() => {
    const saved = localStorage.getItem('sablon_items');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('sablon_expenses');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [payments, setPayments] = useState<Payment[]>(() => {
    const saved = localStorage.getItem('sablon_payments');
    return saved ? JSON.parse(saved) : [];
  });

  const [settings, setSettings] = useState<Settings>(() => {
    const saved = localStorage.getItem('sablon_settings');
    return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
  });

  // Supabase Initial Fetch
  useEffect(() => {
    if (supabase) {
      const fetchData = async () => {
        try {
          const { data: itemsData } = await supabase.from('items').select('*');
          if (itemsData) setItems(itemsData);

          const { data: expensesData } = await supabase.from('expenses').select('*');
          if (expensesData) setExpenses(expensesData);

          const { data: paymentsData } = await supabase.from('payments').select('*');
          if (paymentsData) setPayments(paymentsData);

          const { data: settingsData } = await supabase.from('settings').select('*').single();
          if (settingsData) setSettings({ ...defaultSettings, ...settingsData });
        } catch (error) {
          console.error("Error fetching from Supabase:", error);
        }
      };
      fetchData();
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('sablon_items', JSON.stringify(items));
  }, [items]);
  
  useEffect(() => {
    localStorage.setItem('sablon_expenses', JSON.stringify(expenses));
  }, [expenses]);
  
  useEffect(() => {
    localStorage.setItem('sablon_payments', JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem('sablon_settings', JSON.stringify(settings));
  }, [settings]);

  const addItem = async (item: Omit<Item, 'id'>) => {
    const newItem = { ...item, id: Date.now().toString(), isPaid: false };
    setItems((prev) => [...prev, newItem]);
    if (supabase) await supabase.from('items').insert([newItem]);
  };

  const updateItem = async (id: string, updatedItem: Omit<Item, 'id'>) => {
    setItems((prev) => prev.map((item) => (item.id === id ? { ...item, ...updatedItem } : item)));
    if (supabase) await supabase.from('items').update(updatedItem).eq('id', id);
  };

  const deleteItem = async (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
    if (supabase) await supabase.from('items').delete().eq('id', id);
  };

  const addExpense = async (expense: Omit<Expense, 'id'>) => {
    const newExpense = { ...expense, id: Date.now().toString() };
    setExpenses((prev) => [...prev, newExpense]);
    if (supabase) await supabase.from('expenses').insert([newExpense]);
  };

  const updateExpense = async (id: string, updatedExpense: Omit<Expense, 'id'>) => {
    setExpenses((prev) => prev.map((expense) => (expense.id === id ? { ...updatedExpense, id } : expense)));
    if (supabase) await supabase.from('expenses').update(updatedExpense).eq('id', id);
  };

  const deleteExpense = async (id: string) => {
    setExpenses((prev) => prev.filter((expense) => expense.id !== id));
    if (supabase) await supabase.from('expenses').delete().eq('id', id);
  };

  const addPayment = async (payment: Omit<Payment, 'id'>, markAsPaid: boolean = false) => {
    const newPayment = { ...payment, id: Date.now().toString() };
    setPayments((prev) => [...prev, newPayment]);
    
    if (supabase) await supabase.from('payments').insert([newPayment]);

    // Mark items as paid if requested
    if (markAsPaid && payment.productionItemIds && payment.productionItemIds.length > 0) {
      setItems((prev) => prev.map((item) => 
        payment.productionItemIds.includes(item.id) ? { ...item, isPaid: true } : item
      ));
      if (supabase) {
         payment.productionItemIds.forEach(itemId => {
             supabase.from('items').update({ isPaid: true }).eq('id', itemId);
         });
      }
    }
  };

  const updatePayment = async (id: string, updatedPayment: Omit<Payment, 'id'>, markAsPaid: boolean = false) => {
    setPayments((prev) => prev.map((payment) => (payment.id === id ? { ...updatedPayment, id } : payment)));
    
    if (supabase) await supabase.from('payments').update(updatedPayment).eq('id', id);

    if (markAsPaid && updatedPayment.productionItemIds && updatedPayment.productionItemIds.length > 0) {
      setItems((prev) => prev.map((item) => 
        updatedPayment.productionItemIds.includes(item.id) ? { ...item, isPaid: true } : item
      ));
      if (supabase) {
         updatedPayment.productionItemIds.forEach(itemId => {
             supabase.from('items').update({ isPaid: true }).eq('id', itemId);
         });
      }
    }
  };

  const deletePayment = async (id: string) => {
    setPayments((prev) => {
      const paymentToDelete = prev.find(p => p.id === id);
      if (paymentToDelete && paymentToDelete.productionItemIds && paymentToDelete.productionItemIds.length > 0) {
        setItems((currentItems) => currentItems.map(item => 
          paymentToDelete.productionItemIds.includes(item.id) ? { ...item, isPaid: false } : item
        ));
        if (supabase) {
            paymentToDelete.productionItemIds.forEach(itemId => {
                supabase.from('items').update({ isPaid: false }).eq('id', itemId);
            });
        }
      }
      return prev.filter((payment) => payment.id !== id);
    });
    
    if (supabase) await supabase.from('payments').delete().eq('id', id);
  };

  const updateSettings = async (newSettings: Settings) => {
    setSettings(newSettings);
    if (supabase) {
      // Upsert assuming there's only one settings row, maybe with id = 1
      await supabase.from('settings').upsert({ id: 1, ...newSettings });
    }
  };

  return (
    <StoreContext.Provider
      value={{
        items,
        expenses,
        payments,
        settings,
        addItem,
        updateItem,
        deleteItem,
        addExpense,
        updateExpense,
        deleteExpense,
        addPayment,
        updatePayment,
        deletePayment,
        updateSettings,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
