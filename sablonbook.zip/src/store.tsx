import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Item, Expense, Payment, Settings } from './types';

const defaultSettings: Settings = {
  appName: 'SABLON PRO',
  appLogo: 'S',
  adminPassword: 'admin123',
};

interface StoreContextType {
  items: Item[];
  expenses: Expense[];
  payments: Payment[];
  settings: Settings;
  addItem: (item: Omit<Item, 'id'>) => void;
  updateItem: (id: string, item: Omit<Item, 'id'>) => void;
  deleteItem: (id: string) => void;
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  updateExpense: (id: string, expense: Omit<Expense, 'id'>) => void;
  deleteExpense: (id: string) => void;
  addPayment: (payment: Omit<Payment, 'id'>, markAsPaid?: boolean) => void;
  updatePayment: (id: string, payment: Omit<Payment, 'id'>, markAsPaid?: boolean) => void;
  deletePayment: (id: string) => void;
  updateSettings: (settings: Settings) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Item[]>(() => {
    const saved = localStorage.getItem('sablon_items');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('sablon_expenses');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [payments, setPayments] = useState<Payment[]>(() => {
    const saved = localStorage.getItem('sablon_payments');
    return saved ? JSON.parse(saved) : [];
  });

  const [settings, setSettings] = useState<Settings>(() => {
    const saved = localStorage.getItem('sablon_settings');
    return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
  });

  useEffect(() => {
    localStorage.setItem('sablon_items', JSON.stringify(items));
  }, [items]);
  
  useEffect(() => {
    localStorage.setItem('sablon_expenses', JSON.stringify(expenses));
  }, [expenses]);
  
  useEffect(() => {
    localStorage.setItem('sablon_payments', JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem('sablon_settings', JSON.stringify(settings));
  }, [settings]);

  const addItem = (item: Omit<Item, 'id'>) => {
    setItems((prev) => [...prev, { ...item, id: Date.now().toString(), isPaid: false }]);
  };

  const updateItem = (id: string, updatedItem: Omit<Item, 'id'>) => {
    setItems((prev) => prev.map((item) => (item.id === id ? { ...item, ...updatedItem } : item)));
  };

  const deleteItem = (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  const addExpense = (expense: Omit<Expense, 'id'>) => {
    setExpenses((prev) => [...prev, { ...expense, id: Date.now().toString() }]);
  };

  const updateExpense = (id: string, updatedExpense: Omit<Expense, 'id'>) => {
    setExpenses((prev) => prev.map((expense) => (expense.id === id ? { ...updatedExpense, id } : expense)));
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((expense) => expense.id !== id));
  };

  const addPayment = (payment: Omit<Payment, 'id'>, markAsPaid: boolean = false) => {
    const newPayment = { ...payment, id: Date.now().toString() };
    setPayments((prev) => [...prev, newPayment]);
    
    // Mark items as paid if requested
    if (markAsPaid && payment.productionItemIds && payment.productionItemIds.length > 0) {
      setItems((prev) => prev.map((item) => 
        payment.productionItemIds.includes(item.id) ? { ...item, isPaid: true } : item
      ));
    }
  };

  const updatePayment = (id: string, updatedPayment: Omit<Payment, 'id'>, markAsPaid: boolean = false) => {
    setPayments((prev) => prev.map((payment) => (payment.id === id ? { ...updatedPayment, id } : payment)));
    
    if (markAsPaid && updatedPayment.productionItemIds && updatedPayment.productionItemIds.length > 0) {
      setItems((prev) => prev.map((item) => 
        updatedPayment.productionItemIds.includes(item.id) ? { ...item, isPaid: true } : item
      ));
    }
  };

  const deletePayment = (id: string) => {
    setPayments((prev) => {
      const paymentToDelete = prev.find(p => p.id === id);
      if (paymentToDelete && paymentToDelete.productionItemIds && paymentToDelete.productionItemIds.length > 0) {
        setItems((currentItems) => currentItems.map(item => 
          paymentToDelete.productionItemIds.includes(item.id) ? { ...item, isPaid: false } : item
        ));
      }
      return prev.filter((payment) => payment.id !== id);
    });
  };

  const updateSettings = (newSettings: Settings) => {
    setSettings(newSettings);
  };

  return (
    <StoreContext.Provider
      value={{
        items,
        expenses,
        payments,
        settings,
        addItem,
        updateItem,
        deleteItem,
        addExpense,
        updateExpense,
        deleteExpense,
        addPayment,
        updatePayment,
        deletePayment,
        updateSettings,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
