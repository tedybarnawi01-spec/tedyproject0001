-- Tabel Pengaturan (Settings)
CREATE TABLE settings (
  id integer PRIMARY KEY,
  "appName" text NOT NULL,
  "appLogo" text NOT NULL,
  "adminPassword" text NOT NULL
);

-- Tabel Items
CREATE TABLE items (
  id text PRIMARY KEY,
  name text NOT NULL,
  "costPrice" numeric NOT NULL,
  "sellingPrice" numeric NOT NULL,
  quantity integer NOT NULL,
  date text NOT NULL,
  "isPaid" boolean DEFAULT false
);

-- Tabel Pengeluaran (Expenses)
CREATE TABLE expenses (
  id text PRIMARY KEY,
  date text NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  amount numeric NOT NULL
);

-- Tabel Pembayaran (Payments)
CREATE TABLE payments (
  id text PRIMARY KEY,
  date text NOT NULL,
  "clientName" text NOT NULL,
  description text,
  amount numeric NOT NULL,
  "productionItemIds" text[]
);
